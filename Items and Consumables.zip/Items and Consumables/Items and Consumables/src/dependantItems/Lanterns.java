package dependantItems;

public class Lanterns {

}
