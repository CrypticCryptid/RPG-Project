package dependantItems;

import itemsAndConsumables.Items;

public class Armor extends Items {
	
}
