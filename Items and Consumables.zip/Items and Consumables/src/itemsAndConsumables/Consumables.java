package itemsAndConsumables;

public interface Consumables {
	
	// Methods //
	//TODO: this is dumb, implement more methods for consumable items
	public void consume();

}
