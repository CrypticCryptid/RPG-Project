package itemsAndConsumables;

import java.awt.Color;

public class Items {
	
	// Private Fields //
	//TODO: add more aspects to items maybe?
	private int itemId;
	private int value;
	private Color rarity;
	private String name;

	// Constructor //
	public Items (Items item) {
		this.itemId = item.itemId;
		this.value = item.Value;
		this.rarity = item.rarity;
		this.name = item.name;
	}

	public boolean isConsumbale() {}
	public boolean isFood() {}
	public boolean isPotion() {}
	public boolean isWeapon() {}
	public boolean isArmor() {}
	public boolean isJunk() {}

}
