package itemsAndConsumables;

import java.awt.Color;

public class Items {
	
	// Private Fields //
	//TODO: add more aspects to items maybe?
	private int itemId;
	private int cost;
	private Color rarity;
	private String name;
	
	// Getters and Setters //
	//TODO: we may not need these... but on second thought we might anyways.
	//i really wish there were a way to collapse all these into one line so then i dont have to scroll for an hour to get to the bottom
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public Color getRarity() {
		return rarity;
	}
	public void setRarity(Color rarity) {
		this.rarity = rarity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
