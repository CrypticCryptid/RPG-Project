package itemsAndConsumables;

public interface Consumables {
	// Methods //
	public void consume();
}
