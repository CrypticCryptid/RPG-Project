package dependantItems;

import itemsAndConsumables.Items;

public class Armor extends Items {
	public Armor(Armor armor) {
        super((Item) armor);
    }
}
