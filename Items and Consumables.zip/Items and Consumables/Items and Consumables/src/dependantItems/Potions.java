package dependantItems;

import itemsAndConsumables.Consumables;
import itemsAndConsumables.Items;

public class Potions extends Items implements Consumables {

	@Override
	public void consume() {
		// TODO Auto-generated method stub
	}
}
