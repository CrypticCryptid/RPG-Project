package dependantItems;

import itemsAndConsumables.Items;

public class Weapons extends Items {
	
	private int attack;

	// Getter and Setter //
	public int getAttack() {
		return attack;
	}
	public void setAttack(int attack) {
		this.attack = attack;
	}
}
